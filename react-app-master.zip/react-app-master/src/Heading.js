import React from 'react'

const Heading = () => {
    return <h1>Welcome to my awesome webpage</h1>
}

export default Heading

